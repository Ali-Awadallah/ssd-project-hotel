package security;

import db.DBConnection;
import model.User;
import java.sql.*;

public class AuthService {

    public User login(String username, String password) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.connect();
            if (conn == null) {
                System.out.println("Database connection failed");
                return null;
            }

            ps = conn.prepareStatement(
                    "SELECT * FROM users WHERE username=?"
            );
            ps.setString(1, username);
            rs = ps.executeQuery();

            if (rs.next()) {
                int attempts = rs.getInt("failed_attempts");

                // Check if account is locked
                Timestamp lockedUntil = rs.getTimestamp("locked_until");
                if (lockedUntil != null && lockedUntil.after(new Timestamp(System.currentTimeMillis()))) {
                    System.out.println("Account locked until: " + lockedUntil);
                    return null;
                }

                if (attempts >= 5) {
                    // Lock account for 15 minutes
                    lockAccount(username);
                    System.out.println("Account locked due to too many failed attempts");
                    return null;
                }

                String storedPassword = rs.getString("password");
                if (storedPassword.equals(password)) {  // Note: In production, use password hashing
                    resetAttempts(username);
                    log(rs.getInt("id"), "Login success");

                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setRole(rs.getString("role"));
                    user.setPassword(rs.getString("password"));

                    return user;
                } else {
                    increaseAttempts(username);
                    log(0, "Login failed for user: " + username);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void lockAccount(String username) throws Exception {
        Connection conn = DBConnection.connect();
        PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE username=?"
        );
        ps.setString(1, username);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    private void increaseAttempts(String username) throws Exception {
        Connection conn = DBConnection.connect();
        PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE username=?"
        );
        ps.setString(1, username);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    private void resetAttempts(String username) throws Exception {
        Connection conn = DBConnection.connect();
        PreparedStatement ps = conn.prepareStatement(
                "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE username=?"
        );
        ps.setString(1, username);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    private void log(int userId, String action) throws Exception {
        Connection conn = DBConnection.connect();
        PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO audit_logs(user_id, action) VALUES (?, ?)"
        );
        ps.setInt(1, userId);
        ps.setString(2, action);
        ps.executeUpdate();
        ps.close();
        conn.close();
    }
}